package de.oemel09.lsf.api;

public interface LsfRequestSuccessfull {
    void onRequestSuccessful(String content);
}
