package de.oemel09.lsf.api;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.widget.Toast;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import de.oemel09.lsf.R;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LsfLoader {

    private static final String LOGGED_IN = "LOGGED_IN";
    private static final String ASI = "ASI";
    private static final String COOKIE = "COOKIE";
    private static final String COOKIE_TIME = "COOKIE_TIME";
    private static final String JSESSION_ID = "JSESSIONID=%s";

    private Context context;
    private LsfApi lsfApi;
    private SharedPreferences prefs;
    private SharedPreferences.Editor editor;
    private LsfRequestListener lsfRequestListener;
    private LsfRequestSuccessfull lsfRequestSuccessfull;

    private String cookie;
    private String asi;

    @SuppressLint("CommitPrefEdits")
    public LsfLoader(Context context, LsfRequestListener lsfRequestListener) {
        this.context = context;
        this.lsfRequestListener = lsfRequestListener;
        this.prefs = PreferenceManager.getDefaultSharedPreferences(context);
        this.editor = prefs.edit();
        this.lsfApi = LsfApiClient.getLsfApi();
    }

    public void getGrades(LsfRequestSuccessfull lsfRequestSuccessful1) {
        this.lsfRequestSuccessfull = lsfRequestSuccessful1;
        lsfRequestListener.onRequestStart();
        if (prefs.getLong(COOKIE_TIME, -1) > System.currentTimeMillis()) {
            setRequiredLoginTokens();
            loadGrades();
        } else {
            performLogin();
        }
    }

    public void getGradeDetails(String gradeDetails, LsfRequestSuccessfull lsfRequestSuccessful1) {
        this.lsfRequestSuccessfull = lsfRequestSuccessful1;
        String nodeId = extractNodeId(gradeDetails);
        lsfRequestListener.onRequestStart();
        lsfApi.loadGradeDetails(getCookie(), asi, nodeId).enqueue(onGradeDetailsCallback);
    }

    private String extractNodeId(String link) {
        Pattern pattern = Pattern.compile("nodeID=(.*?)&");
        Matcher matcher = pattern.matcher(link);
        String nodeId = null;
        if (matcher.find()) {
            nodeId = decodeNoteId(matcher.group(1));
        }
        return nodeId;
    }

    private String decodeNoteId(String nodeId) {
        try {
            return URLDecoder.decode(nodeId, "UTF-8");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private void setRequiredLoginTokens() {
        cookie = prefs.getString(COOKIE, "");
        asi = prefs.getString("ASI", "");
    }

    private void performLogin() {
        lsfApi.performLogin(new LsfLogin(context).getFormData()).enqueue(onLoginCallback);
    }

    private void getAsiToken() {
        lsfApi.loadAsiToken(getCookie()).enqueue(onGetAsiCallback);
    }

    private void loadGrades() {
        lsfApi.loadGrades(getCookie(), asi).enqueue(onLoadingGradesCallback);
    }

    @NonNull
    private String getCookie() {
        return String.format(JSESSION_ID, cookie);
    }

    private Callback<ResponseBody> onLoginCallback = new Callback<ResponseBody>() {
        @Override
        public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
            if (response.isSuccessful() && response.body() != null) {
                String content = responseToString(response.body());
                validateResponse(content);
            } else {
                failedToLogIn();
            }
        }

        private void validateResponse(String content) {
            if (!content.contains(context.getString(R.string.result_login_failed))) {
                Pattern pattern = Pattern.compile("jsessionid=(.*?)\\?");
                Matcher matcher = pattern.matcher(content);
                if (matcher.find()) {
                    cookie = matcher.group(1);
                    editor.putString(COOKIE, cookie);
                    editor.putLong(COOKIE_TIME, System.currentTimeMillis() + 28 * 60 * 1000);
                    editor.putBoolean(LOGGED_IN, true);
                    editor.apply();
                    getAsiToken();
                } else {
                    failedToLogIn();
                }
            } else {
                failedToLogIn();
                editor.putBoolean(LOGGED_IN, false).apply();
                lsfRequestListener.onRequestFailedCompletely();
            }
        }

        @Override
        public void onFailure(Call<ResponseBody> call, Throwable t) {
            failedToLogIn();
        }
    };

    private Callback<ResponseBody> onGetAsiCallback = new Callback<ResponseBody>() {
        @Override
        public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
            if (response.isSuccessful() && response.body() != null) {
                String content = responseToString(response.body());
                validateResponse(content);
                loadGrades();
            } else {
                failedToLogIn();
            }
        }

        private void validateResponse(String result) {
            Pattern pattern = Pattern.compile("asi=(.*?)\"");
            Matcher matcher = pattern.matcher(result);
            if (matcher.find()) {
                asi = matcher.group(1);
                editor.putString(ASI, asi).apply();
            } else {
                failedToLogIn();
            }
        }

        @Override
        public void onFailure(Call<ResponseBody> call, Throwable t) {
            failedToLogIn();
        }
    };

    private Callback<ResponseBody> onLoadingGradesCallback = new Callback<ResponseBody>() {
        @Override
        public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
            if (response.isSuccessful() && response.body() != null) {
                String content = responseToString(response.body());
                lsfRequestSuccessfull.onRequestSuccessful(content);
            } else {
                failedToLogIn();
            }
        }

        @Override
        public void onFailure(Call<ResponseBody> call, Throwable t) {
            failedToLogIn();
        }
    };

    private Callback<ResponseBody> onGradeDetailsCallback = new Callback<ResponseBody>() {
        @Override
        public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
            if (response.isSuccessful() && response.body() != null) {
                String content = responseToString(response.body());
                lsfRequestSuccessfull.onRequestSuccessful(content);
            } else {
                failedToLogIn();
            }
        }

        @Override
        public void onFailure(Call<ResponseBody> call, Throwable t) {
            lsfRequestListener.onRequestFailed();
            Toast.makeText(context, context.getString(R.string.no_grade_details), Toast.LENGTH_SHORT).show();
        }
    };

    private String responseToString(ResponseBody body) {
        try {
            return body.string();
        } catch (IOException e) {
            e.printStackTrace();
            return "";
        }
    }

    private void failedToLogIn() {
        lsfRequestListener.onRequestFailed();
        Toast.makeText(context, context.getString(R.string.login_failed), Toast.LENGTH_SHORT).show();
    }
}
