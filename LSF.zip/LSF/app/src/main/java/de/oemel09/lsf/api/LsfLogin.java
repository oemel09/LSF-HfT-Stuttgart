package de.oemel09.lsf.api;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import java.util.HashMap;
import java.util.Map;

import de.oemel09.lsf.R;

import static de.oemel09.lsf.MainActivity.PASSWORD;
import static de.oemel09.lsf.MainActivity.USERNAME;

class LsfLogin {

    private static final String LSF_USERNAME_KEY = "asdf";
    private static final String LSF_PASSWORD_KEY = "fdsa";
    private static final String LSF_SUBMIT_KEY = "submit";

    private String username;
    private String password;
    private String submit;

    LsfLogin(Context context) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        this.username = prefs.getString(USERNAME, null);
        this.password = prefs.getString(PASSWORD, null);
        this.submit = context.getString(R.string.submit_value);
    }

    Map<String, String> getFormData() {
        HashMap<String, String> formData = new HashMap<>();
        formData.put(LSF_USERNAME_KEY, username);
        formData.put(LSF_PASSWORD_KEY, password);
        formData.put(LSF_SUBMIT_KEY, submit);
        return formData;
    }
}
