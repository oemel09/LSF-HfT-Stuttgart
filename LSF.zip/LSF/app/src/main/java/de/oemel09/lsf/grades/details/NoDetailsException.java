package de.oemel09.lsf.grades.details;

public class NoDetailsException extends Exception {
}
