package de.oemel09.lsf.api;

public interface LsfRequestListener {
    void onRequestStart();
    void onRequestFailed();
    void onRequestFailedCompletely();
}

