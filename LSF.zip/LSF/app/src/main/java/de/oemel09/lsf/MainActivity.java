package de.oemel09.lsf;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Objects;

import de.oemel09.lsf.api.LsfLoader;
import de.oemel09.lsf.api.LsfRequestListener;
import de.oemel09.lsf.grades.Grade;
import de.oemel09.lsf.grades.GradeAdapter;
import de.oemel09.lsf.grades.GradeParser;
import de.oemel09.lsf.grades.details.GradeDetails;
import de.oemel09.lsf.grades.details.GradeDetailsActivity;
import de.oemel09.lsf.grades.details.GradeDetailsParser;
import de.oemel09.lsf.grades.details.NoDetailsException;

public class MainActivity extends AppCompatActivity implements LsfRequestListener,
        GradeAdapter.OnGradeClickListener {

    private static final String LOGGED_IN = "LOGGED_IN";
    public static final String USERNAME = "USERNAME";
    public static final String PASSWORD = "PASSWORD";
    public static final String GRADE = "GRADE";

    private SharedPreferences prefs;
    private SharedPreferences.Editor editor;
    private GradeAdapter gradesAdapter;
    private ArrayList<Grade> grades;
    private ProgressDialog loadingDialog;
    private LsfLoader lsfLoader;

    @SuppressLint("CommitPrefEdits")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = PreferenceManager.getDefaultSharedPreferences(this);
        editor = prefs.edit();
        if (prefs.getBoolean(LOGGED_IN, false)) {
            setupGradeView();
        } else {
            setupLoginView();
        }
    }

    private void setupGradeView() {
        setContentView(R.layout.activity_main);
        configureRecyclerView();
        lsfLoader = new LsfLoader(this, this);
        lsfLoader.getGrades(this::allGradesLoaded);
    }

    private void allGradesLoaded(String content) {
        grades.addAll(new GradeParser().parse(content));
        gradesAdapter.notifyDataSetChanged();
        loadingDialog.cancel();
    }

    private void configureRecyclerView() {
        RecyclerView rvGrades = findViewById(R.id.rv_grades);
        rvGrades.setLayoutManager(new LinearLayoutManager(this));
        grades = new ArrayList<>();
        gradesAdapter = new GradeAdapter(grades);
        gradesAdapter.setOnGradeClickListener(this);
        rvGrades.setAdapter(gradesAdapter);
    }

    private void setupLoginView() {
        setContentView(R.layout.login);
        if (prefs.getString(USERNAME, null) != null) {
            ((TextInputEditText) findViewById(R.id.et_username)).setText(prefs.getString(USERNAME, null));
        }
        findViewById(R.id.btn_login).setOnClickListener(v -> {
            editor.putString(USERNAME, Objects.requireNonNull(((TextInputEditText) findViewById(R.id.et_username)).getText()).toString());
            editor.putString(PASSWORD, Objects.requireNonNull(((TextInputEditText) findViewById(R.id.et_password)).getText()).toString());
            editor.apply();
            setupGradeView();
        });
    }

    @Override
    public void onRequestStart() {
        showLoadingDialog();
    }

    private void showLoadingDialog() {
        loadingDialog = new ProgressDialog(this);
        loadingDialog.setIndeterminate(true);
        loadingDialog.setCancelable(false);
        loadingDialog.setMessage(getString(R.string.loading));
        loadingDialog.show();
    }

    @Override
    public void onRequestFailed() {
        loadingDialog.cancel();
    }

    @Override
    public void onRequestFailedCompletely() {
        setupLoginView();
    }

    @Override
    public void onGradeClick(Grade grade) {
        showDetailsPage(grade);
    }

    private void showDetailsPage(Grade grade) {
        if (grade.getGradeDetailsLink() == null) {
            Toast.makeText(this, getString(R.string.no_grade_details), Toast.LENGTH_SHORT).show();
        } else {
            if (grade.getGradeDetails() == null) {
                lsfLoader.getGradeDetails(grade.getGradeDetailsLink(), content -> {
                    parseGradeDetails(grade, content);
                    loadingDialog.cancel();
                    startDetailsActivity(grade);
                });
            } else {
                startDetailsActivity(grade);
            }
        }
    }

    private void parseGradeDetails(Grade grade, String content) {
        try {
            GradeDetails gradeDetails = new GradeDetailsParser().parse(content);
            grade.setGradeDetails(gradeDetails);
        } catch (NoDetailsException e) {
            e.printStackTrace();
            Toast.makeText(this, getString(R.string.no_grade_details), Toast.LENGTH_SHORT).show();
        }
    }

    private void startDetailsActivity(Grade grade) {
        Intent startDetailsActivity = new Intent(this, GradeDetailsActivity.class);
        startDetailsActivity.putExtra(GRADE, grade);
        startActivity(startDetailsActivity);
    }
}
