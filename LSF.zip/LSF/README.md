# LSF-HfT-Stuttgart
Small app to access your grades without inserting your password every time and clicking through the menu like crazy

# Download the apk here
[Version 1.0](https://www.oemel09.de/downloads/LSF-App/LSF_1.0.apk)
